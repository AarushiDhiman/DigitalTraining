name="Aarushi Dhiman"
salary=80000
echo "Hello $name"
echo "Salary: $salary"

echo "salary: $((salary*20))"
num1=10
num2=20
echo "sum: $((num1+num2))"